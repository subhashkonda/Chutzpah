
class ABC {
    vowels: string;
    constructor(public content: string) {
        this.vowels = content;
    }

    return10() {
        return 10;
    }
}
