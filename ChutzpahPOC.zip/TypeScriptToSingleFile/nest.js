var ABC = (function () {
    function ABC(content) {
        this.content = content;
        this.vowels = content;
    }
    ABC.prototype.return10 = function () {
        return 10;
    };
    return ABC;
})();
