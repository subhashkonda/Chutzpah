/// <reference path="jasmine.d.ts" />
/// <reference path="../code.ts" />
/// <reference path="../nest.ts" />
/// <chutzpah_reference path="jasmine.js" />
describe("general", function () {
    it("A basic test", function () {
        expect(true).toBeTruthy();
        var value = "hello";
        expect("hello").toEqual(value);
    });
});
describe("stringLib", function () {
    it("will get vowel count", function () {
        var stringPlus = new StringPlus("hello");
        var count = stringPlus.countVowels();
        expect(count).toEqual(2);
    });
});
describe("nest", function () {
    it("add ", function () {
        var stringPlus = new StringPlus("hello");
        var count = stringPlus.countNs();
        expect(count).toEqual(10);
    });
});
describe("nest", function () {
    it("add ", function () {
        var abcObj = new ABC("asdf");
        expect(abcObj.return10()).toEqual(10);
    });
});
